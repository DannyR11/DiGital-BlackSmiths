#!/bin/bash
kill $(cat wilsa.server.pid)
