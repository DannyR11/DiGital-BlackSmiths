sudo apt-get install libzbar-dev build-essential libssl-dev libffi-dev python-dev python3-dev
