from __future__ import unicode_literals

from tests.base import BaseTestCase


class TestMJPEGStreamer(BaseTestCase):

    CLIENT_PER_TEST = True

    def test_pass(self):
        pass