This is a webservice test plugin for Moodle

It's meant to test authentication capability in retrieving a token for an already existing
user and sending that token to a client application.