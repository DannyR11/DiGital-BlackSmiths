<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<!--Insert your own name and surname-->
		<meta name="author" content="Daniel Rocha" />
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<title>Profile Page</title> 
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="icon" type="image/gif" href="favicon/animated_favicon1.gif">


<style>
		@font-face {
		   font-family: myFonta;
		   src: url(blackchancery/yonder.ttf);
		}

		legend, label {
		   font-family: myFonta;
		   color: #00008B;
		}
</style>


	<script type="text/javascript">

        $(document).ready(function () {
            $("#Readtok").click(function () {
                $("#tokentype").load('updateProfile.php');
            });
        });
     </script>

											
	</head>
	<body>
	



	
		<div class="container" id="shift">
			<div class="row" id="col">
				<div class="col-md-6 col-sm-6 col-xs-6" id="col">
				
				<div class="panel panel-default">
				<div class="panel-body" id="col">
				
					<form action="update.php" method="post" id="col">
						<fieldset >
							<legend>User Profile</legend>
							
							<div class="form-group">
								<?php

									session_start();
									define('DB_SERVER', 'localhost');
									define('DB_USERNAME', 'root');
									define('DB_PASSWORD', "");
									define('DB_DATABASE', 'dblogin');
							 
									$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
										
									$output = '';
								    
									
										$seller = $_SESSION["username"];


										$sql = "SELECT * FROM items WHERE seller_name = '$seller' ORDER BY item_id DESC";
							    		$result = $db->query($sql);

							    		if ($result->num_rows > 0) 
							    		{
							    			// output data of each row						    
							    			$row = $result->fetch_assoc();
							    			

							    				$imageP = $row['picName'];
							    				$imagePro = $row['picProName'];
							    				
							    				
							    				echo "<span id='imagepre'><img  src='$imagePro' style='margin-left:160px' width='220' height='220'/></span>";
							    				
							    								
							    			
							    		} 
							    		else 
							    		{
							    			echo "0 results";
							    		}



										$sql = "SELECT * FROM tbUser WHERE name = '$seller'";
							    		$result = $db->query($sql);


							    		if ($result->num_rows > 0) 
							    		{
							    			// output data of each row						    
							    			while($row = $result->fetch_assoc()) 
							    			{
							    				echo "<h1 style='color:red'> $seller $row[surname] </h1>";
							    				echo "<div class='row'>
								    				<div class='col-md-2'>
								    				</div>
								    					<div class='col-md-6' style='margin-left:40px'>
								    					  <div class='thumbnail'>
								    					    <div class='caption-full'>
								    					    <h3>
								    					      <a> Name and Surname: </a>
								    					      <input  id='col' style='color:blue' name='names' id='names' value='$row[name]'/>
								    					      <input name='surnames' id='surnames' value='$row[surname]'/>
								    					      <a> Password and Email: </a>
								    					      <input  id='col'  style='color:blue' name='passwords' id='passwords' value='$row[password]'/>
								    					      <input name='emails' id='emails' value='$row[email]'/>
								    					      <a> birthday: </a>
								    					      <input  id='col'  style='color:blue' name='birthdays' id='birthdays' value='$row[birthday]'/>
								    					      <a> About: </a>
								    					      <input  id='col'  style='color:blue' name='abouts' id='abouts' value='$row[about]'/>
								    					      <a> Contact Details: </a>
								    					      <input name='details' id='details' value='$row[details]'/>
								    					      <a> Administer: </a>
								    					      <input  name='administers' id='administers' value='$row[administer]'/>
								    					    </div><!--caption-full-->
								    					  </div><!--thumbnail-->
								    					</div><!--col--> </h3>";
							    								
							    			}
							    		} 
							    		else 
							    		{
							    			echo "0 results";
							    		}


function updateProfile(){
   echo "<a>The select function is called.</a>";
}
									?>	
							</div>


							<input type="button" style='margin-left:180px' value="Close this window" onclick="location.href = 'login.php';">
							<input type="button" style='margin-left:180px' style='padding-bottom:40px' value="View all profiles" onclick="location.href = 'ProfileAll.php';">
							<div style='margin-right:180px margin-bottom:40px'>
							<button type="submit" style='padding-right:28.5px'  value="Update profile"><a style='color:red'> Update Profile </a>
							</div>



						</fieldset>
					</form>
					
				</div><!--/panel-body-->
				</div><!--/panel-->
				
				</div> <!--/col1-->

			
					<?php

										$sql = "SELECT * FROM items WHERE seller_name = '$seller' ORDER BY item_id DESC";
							    		$result = $db->query($sql);

							    		if ($result->num_rows > 0) 
							    		{
							    			echo "<h1 style='color:red' style='margin-left:28px'> Advertisements </h1>";
							    			// output data of each row						    
							    			while($row = $result->fetch_assoc()) 
							    			{

							    				$imageP = $row['picName'];
							    				$imagePro = $row['picProName'];


							    				
							    				echo "<div class='row'>
							    				<div class='col-md-2'>
							    				</div>
							    					<div class='col-md-5'>
							    					  <div class='thumbnail'>
							    					    <div class='caption-full'>
							    					      <h2 class='pull-right'>R".$row["price"]."</h4><span id='imagepre'><img src='$imageP' width='120' height='120'/><img src='$imagePro' width='120' height='120'/></span>
							    					      </h2><h4><a href='#'>".$row["itemName"]."</a>
							    					      </h4>
							    					      <p>
							    						Posted By ".$row["seller_name"]." on ".$row["creation_date"]."
							    						<br/ > Category: " . $row["itemCateg"] . "

							    						
							    						<div class='buttonbox'>
							    						  <button class'btn text-center' type='button' name='button'>Buy</button>
							    						</div> <div class='col-md-2'>
							    					      </p>
															</div>
							    					    </div><!--caption-full-->
							    					  </div><!--thumbnail-->
							    					</div><!--col-->";
							    								
							    			}
							    		} 
							    		else 
							    		{
							    			echo "0 results";
							    		}
								   
								?>
					
					







					
				</div>
		

				
			</div><!--/row-->
		</div><!--/container-->

		<script src="jquery.js" > </script>
		<script src="script.js" > </script>
		
	</body>
</html>
