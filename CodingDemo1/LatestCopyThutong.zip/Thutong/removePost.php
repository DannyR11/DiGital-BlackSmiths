<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<!---->
		<meta name="author" content="Daniel Rocha" />
		<title>IMY 220 - A3</title> 

		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

		<link rel="stylesheet" href="css/login-style.css">


	</head>
	<body>
		<div class="container">

			<div class="row">
r
				<?php
								
					$itemName = $_GET["itemName"];

					define('DB_SERVER', 'localhost');
					define('DB_USERNAME', 'root');
					define('DB_PASSWORD', "");
					define('DB_DATABASE', 'dblogin');

					 
					$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
														

					$delete = "DELETE from items WHERE itemName ='$itemName'";
					
					
					$result = mysqli_query($db,$delete);

					header('Location: adminHome.php');
					
					
				?>
			</div><!--/row-->
		</div><!--/container-->
		
	</body>
</html>
